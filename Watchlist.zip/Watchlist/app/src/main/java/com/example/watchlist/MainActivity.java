package com.example.watchlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;

public class TickerListFragment extends Fragment {
    private RecyclerView recyclerView:
    private TickerListAdapter adapter;

    public TickerListFragment () { adapter = new TickerListAdapter ();}

    public View onCreateView {
        LayoutInflater = new TickerListAdapter ();
    View view = inflater. inflate (R.layout.fragment_ticker_list, container,
            recyclerView = view. findViewbyId (R.id.recyclerViewTickerList);
    recyclerView.setlayoutManager(new LinearLayoutManager(getActivity()))
    );
    recyclerView.setAdapter(adapter);
    recyclerView.addOnItemTouchListener(new RecyclerItemClickListner (getActivity()),}
    }}};
return view;

public void updateTickers(List<String> tickers) {
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}